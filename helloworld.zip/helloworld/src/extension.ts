import * as vscode from "vscode";

export async function activate(context: vscode.ExtensionContext) {
  console.log("CodeFlow extension activation started");

  let disposable = vscode.commands.registerCommand(
    "codeflow.visualize",
    async (uri: vscode.Uri) => {
      console.log("Command codeflow.visualize triggered");
      resetGlobalState();

      if (panel) {
        panel.dispose();
        panel = undefined;
      }

      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        console.log("No active editor");
        vscode.window.showErrorMessage("No active editor");
        return;
      }

      console.log(`Active editor: ${editor.document.uri.fsPath}`);
      const position = editor.selection.active;
      console.log(
        `Cursor position: Line ${position.line}, Character ${position.character}`
      );
      const document = editor.document;

      try {
        console.log("Preparing call hierarchy");
        const callHierarchyItems = await vscode.commands.executeCommand<
          vscode.CallHierarchyItem[]
        >("vscode.prepareCallHierarchy", document.uri, position);
        console.log("Call hierarchy prepared" + callHierarchyItems);
        if (callHierarchyItems && callHierarchyItems.length > 0) {
          console.log(`Root item: ${callHierarchyItems[0].name}`);
          console.log("Fetching full call hierarchy");
          const newFlowData = await fetchFullCallHierarchy(
            callHierarchyItems[0]
          );
          mergeFlowData(newFlowData);
          showFlowDiagram(globalData, context);
        } else {
          console.log("No call hierarchy found");
          vscode.window.showInformationMessage(
            "No call hierarchy found for the selected function"
          );
        }
      } catch (error) {
        console.error("Error generating CodeFlow:", error);
        vscode.window.showErrorMessage("Error generating CodeFlow: " + error);
      }
    }
  );

  context.subscriptions.push(disposable);
  console.log("CodeFlow extension activation completed");
}

function getRandomPastelColor(): string {
  const hue = Math.floor(Math.random() * 360);
  return `hsl(${hue}, 100%, 85%)`;
}

let panel: vscode.WebviewPanel | undefined;
let globalData: { nodes: any[]; edges: any[] } = { nodes: [], edges: [] };
let nodePositions: Map<number, { x: number; y: number }> = new Map();

let nextNodeId = 1;

// Modify the showFlowDiagram function
function showFlowDiagram(
  data: { nodes: any[]; edges: any[] },
  context: vscode.ExtensionContext
) {
  console.log("Creating or updating webview panel");
  if (panel) {
    panel.webview.postMessage({
      command: "updateDiagram",
      data: data,
      positions: Array.from(nodePositions.entries()),
    });
  } else {
    panel = vscode.window.createWebviewPanel(
      "codeFlow",
      `CodeFlow: ${data.nodes[0]?.label || "Function Diagram"}`,
      vscode.ViewColumn.Beside,
      { enableScripts: true }
    );
    panel.webview.html = getWebviewContent(data);

    panel.webview.onDidReceiveMessage(
      (message) => {
        if (message.command === "goToDefinition") {
          goToDefinition(message.nodeId);
        }
      },
      undefined,
      context.subscriptions
    );

    panel.onDidDispose(
      () => {
        panel = undefined;
        resetGlobalState();
      },
      null,
      context.subscriptions
    );
  }
  globalData = data;
}

// Modify visualizeNode to accept context
export async function visualizeNode(
  nodeId: number,
  context: vscode.ExtensionContext
) {
  const node = globalData.nodes.find((n) => n.id === nodeId);
  if (!node) {
    return;
  }

  try {
    const document = await vscode.workspace.openTextDocument(
      vscode.Uri.file(node.file)
    );
    const position = new vscode.Position(node.line, node.character);

    console.log(
      `Requesting call hierarchy for node ${nodeId} at ${node.file}:${position.line},${position.character}`
    );
    const callHierarchyItems = await vscode.commands.executeCommand<
      vscode.CallHierarchyItem[]
    >("vscode.prepareCallHierarchy", document.uri, position);

    if (callHierarchyItems && callHierarchyItems.length > 0) {
      const outgoingCalls = await vscode.commands.executeCommand<
        vscode.CallHierarchyOutgoingCall[]
      >("vscode.provideOutgoingCalls", callHierarchyItems[0]);

      const newData = await generateFlowDiagramFromCallHierarchy(
        callHierarchyItems[0],
        outgoingCalls
      );
      mergeFlowData(newData);
      showFlowDiagram(globalData, context);
    }
  } catch (error) {
    console.error("Error in visualizeNode:", error);
    vscode.window.showErrorMessage("Error visualizing node: " + error);
  }
}

export async function generateFlowDiagramFromCallHierarchy(
  item: vscode.CallHierarchyItem,
  outgoingCalls: vscode.CallHierarchyOutgoingCall[] | undefined
): Promise<{ nodes: any[]; edges: any[] }> {
  let newNodes = new Map();
  let newEdges: any[] = [];

  const rootKey = `${item.uri.fsPath}::${item.name}`;
  newNodes.set(rootKey, {
    id: 1,
    label: item.name,
    color: getRandomPastelColor(),
    file: item.uri.fsPath,
    line: item.range.start.line,
    character: item.selectionRange.start.character,
  });

  let nodeIdCounter = 2;

  if (outgoingCalls) {
    outgoingCalls.forEach((call) => {
      const calleeKey = `${call.to.uri.fsPath}::${call.to.name}`;
      if (!newNodes.has(calleeKey)) {
        newNodes.set(calleeKey, {
          id: nodeIdCounter++,
          label: call.to.name,
          color: getRandomPastelColor(),
          file: call.to.uri.fsPath,
          line: call.to.range.start.line,
          character: call.to.selectionRange.start.character,
        });
      }
      const calleeId = newNodes.get(calleeKey).id;
      newEdges.push({ from: 1, to: calleeId, count: call.fromRanges.length });
    });
  }

  return {
    nodes: Array.from(newNodes.values()),
    edges: newEdges,
  };
}

async function fetchFullCallHierarchy(rootItem: vscode.CallHierarchyItem) {
  let nodes = new Map();
  let edges: any[] = [];
  let queue = [rootItem];
  let nodeIdCounter = 1;

  function isUserDefined(uri: vscode.Uri): boolean {
    return vscode.workspace.getWorkspaceFolder(uri) !== undefined;
  }

  while (queue.length > 0) {
    let item = queue.shift();
    if (!item || !isUserDefined(item.uri)) {
      continue;
    }

    const itemKey = `${item.uri.fsPath}::${item.name}`;
    if (!nodes.has(itemKey)) {
      nodes.set(itemKey, {
        id: nodeIdCounter++,
        label: item.name,
        color: getRandomPastelColor(),
        file: item.uri.fsPath,
        line: item.range.start.line,
        character: item.selectionRange.start.character,
      });
    }

    const parentId = nodes.get(itemKey).id;

    try {
      const outgoingCalls = await vscode.commands.executeCommand<
        vscode.CallHierarchyOutgoingCall[]
      >("vscode.provideOutgoingCalls", item);
      console.log("outgoingCalls -> ", outgoingCalls);
      console.log(
        `Fetched ${outgoingCalls?.length} outgoing calls for ${item.name}`
      );

      if (outgoingCalls) {
        for (let call of outgoingCalls) {
          if (!isUserDefined(call.to.uri)) {
            continue;
          }

          const calleeKey = `${call.to.uri.fsPath}::${call.to.name}`;
          if (!nodes.has(calleeKey)) {
            nodes.set(calleeKey, {
              id: nodeIdCounter++,
              label: call.to.name,
              color: getRandomPastelColor(),
              file: call.to.uri.fsPath,
              line: call.to.range.start.line,
              character: call.to.selectionRange.start.character,
            });
          }
          const calleeId = nodes.get(calleeKey).id;
          edges.push({
            from: parentId,
            to: calleeId,
            count: call.fromRanges.length,
          });
          queue.push(call.to);
        }
      }
    } catch (error) {
      console.error("Error fetching outgoing calls:", error);
    }
  }

  return {
    nodes: Array.from(nodes.values()),
    edges: edges,
  };
}

async function goToDefinition(nodeId: number) {
  const node = globalData.nodes.find((n) => n.id === nodeId);
  if (!node) {
    return;
  }

  const document = await vscode.workspace.openTextDocument(
    vscode.Uri.file(node.file)
  );
  const position = new vscode.Position(node.line, node.character);

  await vscode.window.showTextDocument(document, {
    viewColumn: vscode.ViewColumn.One,
  });
  const editor = vscode.window.activeTextEditor;
  if (editor) {
    editor.selection = new vscode.Selection(position, position);
    editor.revealRange(
      new vscode.Range(position, position),
      vscode.TextEditorRevealType.InCenter
    );
  }
}

// Modify the getWebviewContent function

/*
function showFlowDiagram(data: {nodes: any[], edges: any[]}, context: vscode.ExtensionContext) {
    console.log('Creating or updating webview panel');
    if (panel) {
        console.log('Updating existing panel');
        panel.webview.postMessage({ command: 'updateDiagram', data: data, positions: Array.from(nodePositions.entries()) });
    } else {
        console.log('Creating new panel');
        panel = vscode.window.createWebviewPanel(
            'codeFlow',
            'CodeFlow Diagram',
            vscode.ViewColumn.Beside,
            {
                enableScripts: true
            }
        );

        panel.webview.html = getWebviewContent(data);

        panel.webview.onDidReceiveMessage(
            message => {
                switch (message.command) {
                    case 'visualize':
                        visualizeNode(message.nodeId, context);
                        return;
                    case 'goToDefinition':
                        goToDefinition(message.nodeId);
                        return;
                    case 'updatePositions':
                        nodePositions = new Map(message.positions);
                        return;
                }
            },
            undefined,
            context.subscriptions
        );

        panel.onDidDispose(
            () => {
                panel = undefined;
            },
            null,
            context.subscriptions
        );
    }
    globalData = data;
}
*/
function getWebviewContent(data: { nodes: any[]; edges: any[] }) {
    return `
          <!DOCTYPE html>
          <html lang="en">
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>CodeFlow Diagram</title>
              <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
              <style>
                  body {
                      background-color: var(--vscode-editor-background);
                      color: var(--vscode-editor-foreground);
                      margin: 0;
                      overflow: hidden;
                  }
                  #toolbar {
                      display: flex;
                      justify-content: space-between;
                      padding: 10px;
                      background: var(--vscode-panel-background);
                      border-bottom: 1px solid var(--vscode-panel-border);
                  }
                  #mynetwork {
                      width: 100vw;
                      height: calc(100vh - 40px);
                      border: 1px solid var(--vscode-panel-border);
                  }
                  button {
                      background: var(--vscode-button-background);
                      color: var(--vscode-button-foreground);
                      border: none;
                      padding: 5px 10px;
                      cursor: pointer;
                  }
                  button:hover {
                      background: var(--vscode-button-hoverBackground);
                  }
              </style>
          </head>
          <body>
              <div id="toolbar">
                  <input type="text" id="search" placeholder="Search nodes..." />
                  <button id="downloadBtn">Download</button>
              </div>
              <div id="mynetwork"></div>
              <script>
                  (function() {
                      console.log("[CodeFlow] Initializing Webview Script");
  
                      // Ensure VS Code API is available
                      const vscode = acquireVsCodeApi();
                      if (!vscode) {
                          console.error("[CodeFlow] VS Code API not found!");
                          return;
                      }
  
                      console.log("[CodeFlow] VS Code API Loaded Successfully");
  
                      // Initialize data sets
                      let nodes = new vis.DataSet(${JSON.stringify(data.nodes)});
                      let edges = new vis.DataSet(${JSON.stringify(data.edges)});
  
                      console.log("[CodeFlow] Nodes Loaded: ", nodes.length);
                      console.log("[CodeFlow] Edges Loaded: ", edges.length);
  
                      // Find container for diagram
                      const container = document.getElementById('mynetwork');
                      if (!container) {
                          console.error("[CodeFlow] ERROR: Network container not found!");
                          return;
                      }
  
                      console.log("[CodeFlow] Network container found");
  
                      // Configure network visualization
                      const dataSets = { nodes: nodes, edges: edges };
                      const options = { nodes: { shape: 'box' }, edges: { arrows: 'to' }, physics: false };
                      const network = new vis.Network(container, dataSets, options);
  
                      console.log("[CodeFlow] Network Diagram Initialized Successfully");
  
                      // Handle Download Button Click
                      const downloadBtn = document.getElementById("downloadBtn");
                      if (!downloadBtn) {
                          console.error("[CodeFlow] ERROR: Download button not found!");
                          return;
                      }
  
                      console.log("[CodeFlow] Download button found");
  
                      downloadBtn.addEventListener("click", () => {
                          console.log("[CodeFlow] Download Button Clicked");
  
                          const networkSVG = document.querySelector("#mynetwork svg");
                          if (!networkSVG) {
                              console.error("[CodeFlow] ERROR: No SVG found!");
                              return;
                          }
  
                          console.log("[CodeFlow] Found SVG, preparing for download");
  
                          const serializer = new XMLSerializer();
                          const svgBlob = new Blob([serializer.serializeToString(networkSVG)], { type: "image/svg+xml" });
                          const link = document.createElement("a");
                          link.href = URL.createObjectURL(svgBlob);
                          link.download = "CodeFlow_Diagram.svg";
  
                          document.body.appendChild(link);
                          link.click();
                          document.body.removeChild(link);
  
                          console.log("[CodeFlow] SVG Download Triggered");
                      });
  
                      // Search Feature for Nodes
                      const searchInput = document.getElementById("search");
                      if (!searchInput) {
                          console.error("[CodeFlow] ERROR: Search input field not found!");
                          return;
                      }
  
                      console.log("[CodeFlow] Search input found");
  
                      searchInput.addEventListener("input", (event) => {
                          let searchTerm = event.target.value.toLowerCase();
                          console.log("[CodeFlow] Searching for:", searchTerm);
  
                          nodes.update(nodes.get().map(node => ({
                              ...node,
                              hidden: searchTerm ? !node.label.toLowerCase().includes(searchTerm) : false
                          })));
  
                          console.log("[CodeFlow] Search Completed");
                      });
  
                  })();
              </script>
          </body>
          </html>
      `;
  }
  
      
function mergeFlowData(newData: { nodes: any[]; edges: any[] }) {
  // Create a map of existing nodes by file+label combination
  const existingNodesMap = new Map(
    globalData.nodes.map((node) => [`${node.file}-${node.label}`, node])
  );

  // Process new nodes
  newData.nodes.forEach((newNode) => {
    const key = `${newNode.file}-${newNode.label}`;
    if (!existingNodesMap.has(key)) {
      // If node doesn't exist, add it with a new ID
      newNode.id = nextNodeId++;
      globalData.nodes.push(newNode);
      existingNodesMap.set(key, newNode);
    }
  });

  // Process new edges
  newData.edges.forEach((newEdge) => {
    // Find the actual node IDs from our existing nodes
    const fromNode = newData.nodes[newEdge.from - 1];
    const toNode = newData.nodes[newEdge.to - 1];

    if (fromNode && toNode) {
      const fromKey = `${fromNode.file}-${fromNode.label}`;
      const toKey = `${toNode.file}-${toNode.label}`;

      const actualFromNode = existingNodesMap.get(fromKey);
      const actualToNode = existingNodesMap.get(toKey);

      if (actualFromNode && actualToNode) {
        // Check if edge already exists
        const edgeExists = globalData.edges.some(
          (e) => e.from === actualFromNode.id && e.to === actualToNode.id
        );

        if (!edgeExists) {
          globalData.edges.push({
            from: actualFromNode.id,
            to: actualToNode.id,
            count: newEdge.count,
          });
        }
      }
    }
  });
}

export function deactivate() {}

function resetGlobalState() {
  globalData = { nodes: [], edges: [] };
  nextNodeId = 1;
  nodePositions = new Map();
  console.log("Global state reset");
}
